package br.ufscar.dc.dsw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginMvcV2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
